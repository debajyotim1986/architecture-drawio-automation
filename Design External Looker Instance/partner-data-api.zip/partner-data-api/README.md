# partner-data-api

The GKE Data API from the Looker Partner Embed runbook (v2) — steps 13–14 of
the v1.4 flow. Called only by Apigee. Per request: verify JWT → resolve tenant
from the Cloud SQL tenancy registry (fail closed) → resolve/validate dashboard
from the tenant's Looker folder → mint a signed SSO embed URL.

## Endpoints
| Route | Purpose |
|---|---|
| `GET /api/v1/session/bootstrap` | THE one call (Apigee, once per login): tenant + tiles + Home embed URL + navigation base |
| `GET /healthz` / `GET /readyz` | Liveness / readiness (readiness pings the registry) |

Single-call pattern: after bootstrap, dashboard switching = iframe src
change against the public Looker host, authorized by the live embed
session + folder ACLs. No further API calls until re-login.

## Env (non-secret; see k8s/deployment.yaml)
GCP_PROJECT, LOOKER_BASE_URL, PUBLIC_LOOKER_EMBED_URL, PORTAL_ORIGIN, PARTNERS_ROOT_FOLDER_ID,
JWKS_URL, JWT_ISSUER, JWT_AUDIENCE, REGISTRY_DATASET
(optional: EMBED_SESSION_LENGTH,
TENANT_CACHE_TTL, DASHBOARD_CACHE_TTL)

## Secrets (Secret Manager, fetched at startup via Workload Identity)
looker-api-client-id · looker-api-client-secret · looker-embed-secret

## Deploy
```
gcloud builds submit -t asia-south1-docker.pkg.dev/PROJECT/apps/partner-data-api:1.0.0 .
kubectl apply -f k8s/ -n data-api
```
Prerequisites: runbook Parts B-1..B-3 (secrets, Workload Identity, registry
schema) and Part D (Looker service user, embed secret, domain allowlist).
