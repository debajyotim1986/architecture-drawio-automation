"""JWT re-validation (flow step 13 — defense in depth behind Apigee's step 11).

Identity comes ONLY from the verified token. Client-sent identity headers are
stripped by Apigee (5c) and ignored here regardless.
"""
import jwt
from fastapi import HTTPException, Request
from jwt import PyJWKClient

from . import config

_jwks = PyJWKClient(config.JWKS_URL, cache_keys=True, lifespan=300)


def verify_jwt(request: Request) -> dict:
    header = request.headers.get("authorization", "")
    if not header.lower().startswith("bearer "):
        raise HTTPException(401, "missing bearer token")
    token = header[7:]
    try:
        key = _jwks.get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            issuer=config.JWT_ISSUER,
            audience=config.JWT_AUDIENCE,
            options={"require": ["exp", "iss", "aud", "sub"]},
        )
    except jwt.PyJWTError as exc:
        raise HTTPException(401, f"invalid token: {exc}") from exc

    if not claims.get("roles"):
        raise HTTPException(403, "no roles claim")
    return claims
