"""Looker integration — folder-driven dashboard mapping + signed SSO embed URL.

The Looker folder Partners/{tenant} IS the tenant->dashboards mapping
(runbook B.9g, option 1): publishing to the folder grants the dashboard;
nothing else to keep in sync. The mint-side allow-list check here is the
security control; the folder ACL (F.8) is the second lock.
"""
import threading

import looker_sdk
from cachetools import TTLCache
from fastapi import HTTPException
from looker_sdk import models40 as mdls

from . import config
from .role_map import ROLE_MAP

sdk = None  # initialised in startup() after secrets are exported

_lock = threading.Lock()
_dash_cache: TTLCache = TTLCache(maxsize=500, ttl=config.DASHBOARD_CACHE_TTL)


def startup() -> None:
    global sdk
    config.export_looker_sdk_env()
    sdk = looker_sdk.init40()


def tenant_dashboards(tenant: str) -> dict[str, str]:
    """{dashboard_id: title} for one tenant, from its Partners/{tenant} folder."""
    with _lock:
        if tenant in _dash_cache:
            return _dash_cache[tenant]

    folders = sdk.search_folders(
        name=tenant, parent_id=config.PARTNERS_ROOT_FOLDER_ID
    )
    if not folders:
        raise HTTPException(403, "tenant has no published content")
    dashes = sdk.folder_dashboards(folder_id=folders[0].id, fields="id,title")
    result = {str(d.id): (d.title or "") for d in dashes}
    if not result:
        raise HTTPException(403, "tenant has no published content")

    with _lock:
        _dash_cache[tenant] = result
    return result


def resolve_dashboard(tenant: str, requested_id: str | None) -> str:
    """Default ('Home', else first) for first render; allow-list check otherwise."""
    allowed = tenant_dashboards(tenant)
    if requested_id is None:
        home = next((i for i, t in allowed.items() if t.lower() == "home"), None)
        return home or next(iter(allowed))
    if requested_id not in allowed:
        raise HTTPException(403, "dashboard not permitted for tenant")
    return requested_id


def build_embed_url(claims: dict, tenant: str, dashboard_id: str) -> str:
    role = claims["roles"][0]
    if role not in ROLE_MAP:
        raise HTTPException(403, "unknown role")
    rm = ROLE_MAP[role]

    resp = sdk.create_sso_embed_url(
        body=mdls.EmbedSsoParams(
            target_url=(
                # PUBLIC host — the browser opens this URL; the SDK itself
                # talks to Looker over LOOKER_BASE_URL (cluster-internal).
                f"{config.PUBLIC_LOOKER_EMBED_URL}/embed/dashboards/{dashboard_id}"
                f"?embed_domain={config.PORTAL_ORIGIN}"
            ),
            external_user_id=f"{tenant}::{claims['sub']}",
            first_name=claims.get("given_name", "Partner"),
            last_name=claims.get("family_name", "User"),
            external_group_id=tenant,
            user_attributes={"tenant_id": tenant},
            permissions=rm["permissions"],
            models=rm["models"],
            session_length=config.EMBED_SESSION_LENGTH,
            force_logout_login=True,
        )
    )
    return resp.url  # single-use, expires in seconds — return, never store/log
