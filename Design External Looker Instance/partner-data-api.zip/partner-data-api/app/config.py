"""Configuration — env vars first, secrets from Secret Manager at startup.

Non-secret values come from the Deployment env; the four secrets are fetched
via the pod's Workload Identity (runbook B.5) and never touch disk or YAML.
"""
import os
from functools import lru_cache

from google.cloud import secretmanager

GCP_PROJECT = os.environ["GCP_PROJECT"]                    # e.g. "acme-analytics-prod"

# --- non-secret settings (Deployment env) -----------------------------------
LOOKER_BASE_URL = os.environ["LOOKER_BASE_URL"]            # e.g. "https://looker-rp.looker.svc.cluster.local:9999" (INTERNAL — SDK only)
PORTAL_ORIGIN = os.environ["PORTAL_ORIGIN"]                # e.g. "https://portal.yourdomain.com" (the iframe parent page)
PUBLIC_LOOKER_EMBED_URL = os.environ["PUBLIC_LOOKER_EMBED_URL"]  # e.g. "https://looker.yourdomain.com" — the host the BROWSER loads
PARTNERS_ROOT_FOLDER_ID = os.environ["PARTNERS_ROOT_FOLDER_ID"]  # e.g. "142" — from the folder URL …/folders/142
JWKS_URL = os.environ["JWKS_URL"]                          # e.g. "https://ida.internal/.well-known/jwks.json"
JWT_ISSUER = os.environ["JWT_ISSUER"]                      # e.g. "https://ida.internal" — must equal the iss claim
JWT_AUDIENCE = os.environ["JWT_AUDIENCE"]                  # e.g. "partner-portal" — must equal the aud claim
REGISTRY_DATASET = os.environ.get("REGISTRY_DATASET", "tenant_registry")  # BigQuery dataset holding tenants/partner_users — SEPARATE from partner_dwh
EMBED_SESSION_LENGTH = int(os.environ.get("EMBED_SESSION_LENGTH", "3600"))  # align with JWT lifetime: one login = one session
TENANT_CACHE_TTL = int(os.environ.get("TENANT_CACHE_TTL", "60"))        # seconds; also the max suspension lag
DASHBOARD_CACHE_TTL = int(os.environ.get("DASHBOARD_CACHE_TTL", "300")) # seconds; folder-list cache per tenant

_sm = secretmanager.SecretManagerServiceClient()


@lru_cache(maxsize=None)
def secret(name: str) -> str:
    """Fetch latest secret version via Workload Identity (ADC)."""
    path = f"projects/{GCP_PROJECT}/secrets/{name}/versions/latest"
    return _sm.access_secret_version(name=path).payload.data.decode()


def export_looker_sdk_env() -> None:
    """looker_sdk reads its credentials from env — set them before init40()."""
    os.environ["LOOKERSDK_BASE_URL"] = LOOKER_BASE_URL
    os.environ["LOOKERSDK_VERIFY_SSL"] = os.environ.get("LOOKERSDK_VERIFY_SSL", "true")
    os.environ["LOOKERSDK_CLIENT_ID"] = secret("looker-api-client-id")
    os.environ["LOOKERSDK_CLIENT_SECRET"] = secret("looker-api-client-secret")
