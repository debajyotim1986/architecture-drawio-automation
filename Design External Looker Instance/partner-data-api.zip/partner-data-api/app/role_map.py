"""Role → Looker capability map (runbook A.2).

Kept in code deliberately: auditable, PR-reviewed, and ID&A does not control
Looker capability. Unknown role => 403, never a permissive default.
"""
ROLE_MAP: dict[str, dict[str, list[str]]] = {
    "viewer": {
        "permissions": ["access_data", "see_user_dashboards", "see_looks"],
        "models": ["partner_analytics"],
    },
    "analyst": {
        "permissions": [
            "access_data", "see_user_dashboards", "see_looks",
            "explore", "download_full_results",
        ],
        "models": ["partner_analytics"],
    },
}
