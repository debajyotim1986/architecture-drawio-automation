"""Partner Data API — the GKE microservice at steps 13-14 of the v1.4 flow.

SINGLE-CALL PATTERN: Apigee calls this API exactly ONCE per login
(/api/v1/session/bootstrap). The response carries everything the portal
needs — tenant, dashboard list, the Home embed URL, and the navigation
base. All later dashboard switching happens INSIDE the established
Looker embed session (iframe src change) with no further API calls;
Looker folder ACLs (runbook F.8/F.9) authorize each navigation.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request

from . import config, looker, registry
from .auth import verify_jwt


@asynccontextmanager
async def lifespan(_: FastAPI):
    looker.startup()
    yield


app = FastAPI(title="partner-data-api", lifespan=lifespan)


# --- health (kubelet only; outside /api/) -----------------------------------
@app.get("/healthz")                    # liveness: no downstream calls
def healthz():
    return {"ok": True}


@app.get("/readyz")                     # readiness: registry must be reachable
def readyz():
    ready = registry.ping()
    return ({"ready": True} if ready
            else ({"ready": False}, 503))


# --- THE one API call (Apigee, once per login) ------------------------------
@app.get("/api/v1/session/bootstrap")
def session_bootstrap(request: Request):
    """Everything the portal needs, in one response:
    tenant, tiles, the signed Home embed URL, and the navigation base
    the SPA uses for in-session dashboard switching (no more API calls)."""
    claims = verify_jwt(request)                      # step 13a
    tenant = registry.get_tenant(claims["sub"])       # step 13b — fail closed
    dashboards = looker.tenant_dashboards(tenant)     # folder = the mapping
    home = looker.resolve_dashboard(tenant, None)     # 'Home', else first
    return {
        "tenant": tenant,
        "dashboards": [{"id": i, "title": t} for i, t in dashboards.items()],
        "home_dashboard_id": home,
        "embed_url": looker.build_embed_url(claims, tenant, home),  # step 14
        "navigation": {
            "embed_base": f"{config.PUBLIC_LOOKER_EMBED_URL}/embed/dashboards/",
            "embed_domain": config.PORTAL_ORIGIN,
            "session_length": config.EMBED_SESSION_LENGTH,
        },
    }
