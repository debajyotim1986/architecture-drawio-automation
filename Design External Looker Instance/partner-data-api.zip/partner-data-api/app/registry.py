"""Tenancy registry (runbook B-3) — partner_id -> tenant_id, stored in BIGQUERY.

OSIS does NOT hold this mapping; the tenant_registry dataset is the authority.
BigQuery is analytical, so two rules keep it safe here:
  1. Uniqueness of partner_id is enforced in the WRITE path (MERGE only) —
     BigQuery's PRIMARY KEY is NOT ENFORCED and cannot protect us.
  2. Reads treat a duplicate partner_id as an INTEGRITY BREACH (500 + alert),
     never "pick one".
One lookup per login (single-call pattern) + 60s cache keeps BQ latency off
the hot path. FAIL CLOSED on anything unknown.
"""
import threading

from cachetools import TTLCache
from fastapi import HTTPException
from google.cloud import bigquery

from . import config

_bq = bigquery.Client(project=config.GCP_PROJECT)
_lock = threading.Lock()
_tenant_cache: TTLCache = TTLCache(maxsize=10_000, ttl=config.TENANT_CACHE_TTL)

_SQL = f"""
    SELECT pu.tenant_id, pu.status AS pstatus, t.status AS tstatus
    FROM `{config.GCP_PROJECT}.{config.REGISTRY_DATASET}.partner_users` pu
    JOIN `{config.GCP_PROJECT}.{config.REGISTRY_DATASET}.tenants` t
      USING (tenant_id)
    WHERE pu.partner_id = @partner_id
"""


def get_tenant(partner_id: str) -> str:
    """Resolve tenant for a partner. 403 (fail closed) if not provisioned."""
    with _lock:
        if partner_id in _tenant_cache:
            return _tenant_cache[partner_id]

    job = _bq.query(
        _SQL,
        job_config=bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("partner_id", "STRING", partner_id)
            ]
        ),
    )
    rows = list(job.result())

    if len(rows) > 1:
        # Impossible via the MERGE-only write path; if seen, the registry has
        # been written around — refuse and page, never guess a tenant.
        raise HTTPException(500, "registry integrity error")
    if not rows or rows[0]["pstatus"] != "active" or rows[0]["tstatus"] != "active":
        # Unknown / disabled partner or suspended tenant:
        # never a default tenant — errors are the safe failure (C.3 principle).
        raise HTTPException(403, "partner not provisioned")

    tenant = rows[0]["tenant_id"]
    with _lock:
        _tenant_cache[partner_id] = tenant
    return tenant


def ping() -> bool:
    """Readiness: the pod is not ready if it cannot resolve tenants (B.19)."""
    try:
        list(_bq.query("SELECT 1").result())
        return True
    except Exception:
        return False
